# Maze-Solver-Game
A fun and interactive Python-based Maze Solver Game built using Tkinter. The player navigates through a randomly generated maze using keyboard controls (Arrow keys or WASD) to reach the exit while the game tracks time, moves, and score.
